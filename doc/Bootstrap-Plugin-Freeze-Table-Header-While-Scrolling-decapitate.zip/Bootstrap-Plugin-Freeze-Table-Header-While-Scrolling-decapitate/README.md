jquery-decapitate
=================

Separating `<thead>` from `<tbody>` since 2013.


Synopsis
--------

The *jquery-decapitate* jQuery plug-in allows you to create fixed (non-scrolling) table headers,
pinned to the top of the viewport while the table body continues to scroll. Unlike most other plug-ins of this sort,
*jquery-decapitate* does not require that you wrap your table in a fixed-height container.

![Screenshot](https://raw.githubusercontent.com/claymation/jquery-decapitate/master/docs/demo.gif)

Features
--------

* Table header scrolls up out of the viewport along with the last table row (similar to an iOS TableView)
* Handles fluid & responsive layouts
* Handles browser window resize events
* Good browser support: IE, Chrome, Firefox, Opera


[Live demo](https://claymation.github.io/jquery-decapitate/)
-------------------------------------------------------------


Dependencies
------------

* [jQuery](http://jquery.com) >= 1.7
* [Bootstrap](http://twitter.github.io/bootstrap/index.html) (only the Affix 
  [plug-in](http://twitter.github.io/bootstrap/customize.html#plugins) is required)


Usage
-----

Call the `decapitate()` method on any valid jQuery selector. For example, to activate fixed table headers
on all `<table>` elements on the page:

    <script>
      $(document).ready(function() {
        $('table').decapitate();
      });
    </script>


Markup
------

The plug-in is so-named because it separates `<thead>` (and optional `<caption>`) elements from
their `<tbody>` element, moving them into a new `<table>` element just above the original.

Assuming standard table markup:

    <table id="foo">
      <caption></caption>
      <thead>
        <tr>...</tr>
      </thead>
      <tbody>
        <tr>...</tr>
      </tbody>
    </table>

the resulting markup after applying `decapitate()` to the table is:
  
    <div id="foo-wrapper" class="decap-body-wrapper">
      <div class="decap-head-wrapper">
        <table class="decap-head">
          <caption>
          <thead>
            <tr>...</tr>
          </thead>
        </table>
      </div>
      <table id="foo" class="decap-body">
        <tbody>
          <tr>...</tr>
        </tbody>
      </table>
    </div>

It looks like [divitis](http://en.wiktionary.org/wiki/divitis), but each `<div>` serves a purpose:

* `div.decap-wrapper` gets `position: relative`, allowing other elements to be positioned absolutely within it
* `div.decap-head-wrapper` gets `position: fixed` when the table header is pinned to the top of the viewport,
  and `position: relative` later when the table header scrolls out of the viewport with the last table row

Note that the original `<table>` element requires an `id`; this `id` is suffixed with `-wrapper` and applied to the
`div.decap-body-wrapper` that wraps both tables, thus allowing styles specific to this table to be applied to
`div.decap-head-wrapper` and `table.decap-head`.


Styles
------

The styles in [`jquery.decapitate.css`](jquery.decapitate.css) serve as a baseline to initialize various elements. They should be applicable in most cases.

Some styles must be customized to use *jquery.decapitate* on your site. Have a look in [`demo/styles.css`](demo/styles.css) for examples.
